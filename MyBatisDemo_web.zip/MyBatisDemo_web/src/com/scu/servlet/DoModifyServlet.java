package com.scu.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.scu.bean.Message;

public class DoModifyServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//���ñ���
		request.setCharacterEncoding("utf-8");
		String id = request.getParameter("id");
		String command = request.getParameter("command");
		String description = request.getParameter("description");
		String content = request.getParameter("content");
		Message message = new Message();
		message.setId(Integer.valueOf(id));
		message.setCommand(command);
		message.setDescription(description);
		message.setContent(content);
		System.out.println(message.getId());
		System.out.println(message.getCommand());
		System.out.println(message.getDescription());
		System.out.println(message.getContent());
		request.setAttribute("message", message);
		
		//��ת��ҳ��
		request.getRequestDispatcher("/WEB-INF/jsp/back/modifylist.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(request, response);
	}
}
