package com.mybatis.test;

import java.util.List;

public interface IUserOperation {

    public User selectUserByID(int id);
	
	public User selectUsersByName(String userName);
	
	public List<User> selectUserList();
	
	public void addUser(User user);
	
	public void updateUser(User user);
	
	public void deleteUser(int id);
}
